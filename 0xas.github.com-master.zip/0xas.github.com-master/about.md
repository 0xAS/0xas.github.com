---
layout: page
title: About
group: navigation
---
{% include JB/setup %}

Hello, this is Jiànwén here. Welcome to my personal website. This website is a place where I record my life, work, and everything. Fell free to contact me if you are interested: 
<a href="mailto:jwsun@jwsun.info">jwsun AT jwsun DOT info </a>.<br><br>

Affiliated to the Institute of Neuroinformatic, ETH/Universität Zürich, I am a PhD student
working at CSEM, a swiss non-profit research institute. My research interest includes deep learning theory, signal 
representation, quality inspection with neural network, etc.<br><br>

Besides work, I like reading, photograph, cycling and fancy food. =)<br>

